import os
from multiprocessing import Pool
import shutil
DATA = "/home/cao/aredflower/meddatasets"

CSC = False
CTP = "end"
CFG = "vit_b16"
import shutil
def run_experiment(args):
    method, model, dataset, shots, seed, gpu_id = args
    METHOD = method
    MODEL = model
    TRAINER = f"{METHOD}_{MODEL}"
    os.environ["CUDA_VISIBLE_DEVICES"] = str(gpu_id) 

    dir_path = f"output/{dataset}/shots_{shots}/{TRAINER}/csc{CSC}_ctp{CTP}/seed{seed}"
    if METHOD == "CoOp" or METHOD == "CoCoOp" or METHOD == "VPT" or METHOD == "DPT" or METHOD == "Maple":
        config_yaml = f'configs/trainers/{METHOD}/{CFG}.yaml'
    else:
        config_yaml = f'configs/trainers/{METHOD}/few_shot/{dataset}.yaml'
    if False:
        print(f"Skipping existing job: {dir_path}")
    else:
        os.makedirs(dir_path, exist_ok=True)
        print(f"Starting experiment: dataset={dataset}, shots={shots}, seed={seed}, gpu={gpu_id}")
        os.system(
            f"python train.py "
            f"--root {DATA} "
            f"--seed {seed} "
            f"--trainer {TRAINER} "
            f"--dataset-config-file configs/datasets/{dataset}.yaml "
            f"--config-file {config_yaml} "
            f"--output-dir {dir_path} "
            f"TRAINER.{method.upper()}.CSC {CSC} "
            f"TRAINER.{method.upper()}.CLASS_TOKEN_POSITION {CTP} "
            f"DATASET.NUM_SHOTS {shots}"
        )
        pro_path = os.path.join(dir_path, 'prompt_learner')
        ten_path = os.path.join(dir_path, 'tensorboard')
        if os.path.exists(pro_path):
            print(f"Deleting directory: {pro_path}")
            shutil.rmtree(pro_path)
        if os.path.exists(ten_path):
            print(f"Deleting directory: {ten_path}")
            shutil.rmtree(ten_path)

if __name__ == "__main__":
    # datasets = ["btmri", "busi", "chmnist", "covid", "ctkidney", "dermamnist", "kneexray", "kvasir", "lungcolon", "octmnist", "retina"]
    shots = [16]

    seeds = [1]
    gpu_ids = [0, 1, 2]  # 假设有 3 块 GPU，可调整
    # methods = ["BiomedDPT", "BiomedCoOp", "KgCoOp", "CoOp", "CoCoOp", "ProGrad"]
    methods = ["CoOp", "Maple", "VPT", "DPT"]
    models = ["CLIP"]
    # 生成任务列表，并循环分配 GPU
    tasks = [
        (method, model, dataset, shot, seed, gpu_ids[(i + j + k + l + h) % len(gpu_ids)])  # 轮流分配 GPU
        for h, model in enumerate(models)
        for k, method in enumerate(methods)
        for i, dataset in enumerate(datasets)
        for j, shot in enumerate(shots)
        for l, seed in enumerate(seeds)
    ]

    with Pool(processes=15) as pool:  # 并行 6 个进程
        pool.map(run_experiment, tasks)